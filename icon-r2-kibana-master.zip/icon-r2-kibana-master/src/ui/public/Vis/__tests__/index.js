describe('Vis Component', function () {
  require('./_AggConfig');
  require('./_AggConfigResult');
  require('./_AggConfigs');
  require('./_Vis');
});
