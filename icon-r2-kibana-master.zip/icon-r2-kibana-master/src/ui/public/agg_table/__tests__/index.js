describe('AggTable Component', function () {
  require('./_group');
  require('./_table');
});
