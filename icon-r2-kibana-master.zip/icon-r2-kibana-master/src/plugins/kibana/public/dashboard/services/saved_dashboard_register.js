define(function (require) {
  return function savedDashboardFn(savedDashboards) {
    return savedDashboards;
  };
});
