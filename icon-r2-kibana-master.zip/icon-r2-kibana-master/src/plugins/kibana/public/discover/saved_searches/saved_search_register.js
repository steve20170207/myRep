define(function (require) {
  return function savedSearchObjectFn(savedSearches) {
    return savedSearches;
  };
});
