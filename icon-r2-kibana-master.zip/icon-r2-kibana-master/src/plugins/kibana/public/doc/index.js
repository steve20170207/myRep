define(function (require, module, exports) {
  require('plugins/kibana/doc/controllers/doc');
});
