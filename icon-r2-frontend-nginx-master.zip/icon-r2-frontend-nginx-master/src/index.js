/* Services *******************************************************************/
require('./services/retrievalService.js');
require('./services/immunizationDataParserService.js');
require('./services/acceptLegalAgreementService');
require('./services/yellowCardFormatterService');
/* End services */
