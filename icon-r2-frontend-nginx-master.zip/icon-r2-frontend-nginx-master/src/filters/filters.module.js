angular.module('icon.filters', []);

require('./ageFilter.js');
require('./hCNFormat.js');
require('./slice.js');
require('./pinFormat.js');
