(function(){
'use strict';

  module.exports = {
    bindings: { diseases: '=' },
    controller: diseasesDisplayController,
    templateUrl: './components/immunization/diseasesDisplay/diseasesDisplay.template.html'
  };

  diseasesDisplayController.$inject = [];
  function diseasesDisplayController () {}

}());
