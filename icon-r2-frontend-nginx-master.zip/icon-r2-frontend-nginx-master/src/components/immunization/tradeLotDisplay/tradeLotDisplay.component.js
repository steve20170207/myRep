(function(){
'use strict';

  module.exports = {
    bindings: { immunization: '<' },
    controller: tradeLotDisplayController,
    templateUrl: './components/immunization/tradeLotDisplay/tradeLotDisplay.template.html'
  };

  tradeLotDisplayController.$inject = [];
  function tradeLotDisplayController () {}

}());
