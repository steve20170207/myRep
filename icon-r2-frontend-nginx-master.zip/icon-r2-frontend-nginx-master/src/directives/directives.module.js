angular.module('icon.directives', []);

require('./iconCompareTo.directive.js');
require('./iconHcnChecksum.directive.js');
require('./iconOiidFormat.directive.js');
require('./iconPinFormat.directive.js');
require('./focus.directive.js');
require('./phoneNumberFormat.directive.js');
require('./ngEnter.directive.js');
